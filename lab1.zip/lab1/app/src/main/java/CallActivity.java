import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class CallActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call);
    }

    public void onAcceptClick(View view) {
        Toast.makeText(this, "Дзвінок взято", Toast.LENGTH_SHORT).show();
    }

    public void onRejectClick(View view) {
        Toast.makeText(this, "Дзвінок відхилено", Toast.LENGTH_SHORT).show();
    }
}
